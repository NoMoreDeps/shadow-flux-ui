import * as Flux from "shadow-flux";

export interface Counter {
  name    : string;
  checked : boolean;
};

export interface CounterState {
  clickNumber: number;
}

export type ClickItemAction = {
  type: "ClickItem",
};

export class CounterStore extends Flux.BaseStore<CounterState> {
  constructor() {
    super();
  }

  protected initState(): void {
    this.nextState({
      clickNumber: 0
    });
  }

  async actionClickItem(payload: ClickItemAction, success: () => void, error: (error: Error) => void, For: (...ids: string[]) => Promise<void>) {
    this.nextState(() => {

      return {
        clickNumber: this.getState().clickNumber! + 1
      };

    });
    this.emit();
    success();
  }

  
}
