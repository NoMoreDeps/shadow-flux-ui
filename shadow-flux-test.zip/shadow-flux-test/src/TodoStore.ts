import * as Flux from "shadow-flux";
import { counterStore, CounterState } from "./Flux";

export interface TodoItem {
  name    : string;
  checked : boolean;
};

export interface TodoState {
  numberOfClick : number;
  items         : Array<TodoItem>;
}

export type AddItemAction = {
  type: "AddItem",
  item: TodoItem
};

export type RemoveItemAction = {
  type: "RemoveItem",
  item: TodoItem
};

export type ClickItemAction = {
  type: "ClickItem",
  item: TodoItem
};

function simpleClone<T>(source: T): T {
  return JSON.parse(JSON.stringify(source));
}

export class TodoStore extends Flux.BaseStore<TodoState> {
  constructor() {
    super();
  }

  protected initState(): void {
    this.nextState({
      numberOfClick: 0,
      items: []
    });
  }

  async actionAddItem(payload: AddItemAction, success: () => void, error: (error: Error) => void, For: (...ids: string[]) => Promise<void>) {
    this.nextState((currentState) => {
      if (currentState.items!.filter(_ => _.name === payload.item.name).length > 0) {
        return currentState;
      };

      const newState = {
        numberOfClick: currentState.numberOfClick,
        items: currentState.items?.map(_ => simpleClone(_))
      } as TodoState;

      newState.items?.unshift(simpleClone(payload.item));
      return newState;
    });
    this.emit();
    success();
  }

  async actionRemoveItem(payload: RemoveItemAction, success: () => void, error: (error: Error) => void, For: (...ids: string[]) => Promise<void>) {
    this.nextState((currentState) => {
      const newState = {
        numberOfClick: currentState.numberOfClick,
        items: currentState.items?.map(_ => simpleClone(_))
      } as TodoState;

      newState.items = newState.items.filter(_ => _.name !== payload.item.name)
      return newState;
    });
    this.emit();
    success();
  }

  async actionClickItem(payload: ClickItemAction, success: () => void, error: (error: Error) => void, For: (...ids: string[]) => Promise<void>) {
    // We wait for this store to finish his process first;
    await For(counterStore);

    this.nextState((currentState) => {
      const newState = {
        numberOfClick: this.getStoreStateByToken<CounterState>(counterStore).clickNumber,
        items: currentState.items?.map(_ => simpleClone(_))
      } as TodoState;

      const itm = newState.items.filter(_ => _.name === payload.item.name)[0];
      itm.checked = !itm?.checked; 

      if (payload.item.name === "error") {
        throw Error("Oups, there is an error");
      }
      return newState;
    });
    this.emit();
    success();
  }

  
}
