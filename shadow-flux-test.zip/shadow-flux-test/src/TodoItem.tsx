import * as React from "react";
import { subscriber } from "./Flux";
import { RemoveItemAction, ClickItemAction } from "./TodoStore";
import {Paper, Typography, List, ListItem, Checkbox, ListItemIcon, ListItemText, ListItemSecondaryAction, IconButton, Switch} from "@material-ui/core";
import {Delete} from "@material-ui/icons";

export function TodoItem(props: {
  checked?: boolean
  text: string;
}) {
  return (
    <ListItem key={props.text}>
      <ListItemIcon>
        <Switch
          key={props.text}
          edge="start"
          checked={props.checked}
          value={props.text}
          tabIndex={-1}
          disableRipple
          onChange={() => subscriber.sendAction({type: "ClickItem", item: {name: props.text}} as ClickItemAction)}
          />
      </ListItemIcon>
      <ListItemText  primary={props.text + " - " + props.checked} />
      <ListItemSecondaryAction>
        <IconButton edge="end" aria-label="comments" onClick={() => subscriber.sendAction({type: "RemoveItem", item: {name: props.text}} as RemoveItemAction)}>
          <Delete />
        </IconButton>
      </ListItemSecondaryAction>
    </ListItem>
  );
}