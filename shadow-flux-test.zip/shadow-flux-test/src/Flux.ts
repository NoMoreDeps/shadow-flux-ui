import * as Flux                       from "shadow-flux"    ;
import { TodoStore    , TodoState }    from "./TodoStore"    ;
import { CounterStore , CounterState } from "./CounterStore" ;

const dispatcher        = new Flux.Dispatcher()           ;
const subscriber        = new Flux.Subscriber(dispatcher) ;
const todoStoreToken    = "TodoStore"                     ;
const todoStore         = new TodoStore()                 ;
const counterStoreToken = "CounterStore"                  ;
const countStore        = new CounterStore()              ;

dispatcher.register(todoStore, todoStoreToken)            ;
dispatcher.register(countStore, counterStoreToken)        ;

export {
  subscriber                        ,
  todoStoreToken    as todoStore    ,
  counterStoreToken as counterStore ,
  CounterState                      ,
  TodoState
};

(window as any).dispatcher = dispatcher;

dispatcher.debug.setDebugOn({
  mode : "postMessage",
  url  : "http://localhost:8081"
});

dispatcher.onError(data => {
  console.table(data);
})