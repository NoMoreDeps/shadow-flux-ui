import * as React    from "react";
import { useState }  from "react";
import { useEffect } from "react";
import { TodoItem }  from "./TodoItem";
import {Paper, Typography, List, Divider, TextField, Button} from "@material-ui/core";

import { 
  TodoState, 
  AddItemAction 
} from "./TodoStore";

import { 
  subscriber, 
  todoStore 
} from "./Flux";

export function Todo() {
  const [state, setState] = useState<TodoState>({
    items: [],
    numberOfClick: 0
  });

  const [current, setCurrent] = useState<string>("");

  useEffect(() => {
    const sub = subscriber.subscribe<TodoState>(todoStore, state => {
      setState(state);
    });

    return () => sub.off();
  }, [])

  return (
    <div>
      <Paper>
        <Typography variant="h5">
          Todo App
        </Typography>
        <List>
          {
            (() => {
              return state.items.map(_ => (
                <TodoItem text={_.name} checked={!!_.checked}/>
              ))
            })()
          }
        </List>
        <Divider />
        <div>
          <TextField
            id="standard-basic"
            label="Standard"
            margin="normal"
            value={current}
            onChange={(event) => setCurrent(event.target.value)}
            fullWidth
            />
          <Button variant="contained" fullWidth onClick={() => {
            subscriber.sendAction({type: "AddItem", item: { name: current}} as AddItemAction);
            setCurrent("");
          }}>
            Add Item
          </Button>
        </div>
      </Paper>
    </div>
  )
}
